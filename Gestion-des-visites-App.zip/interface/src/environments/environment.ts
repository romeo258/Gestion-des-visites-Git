


export const environment = {
    production: false,
    apiBaseUrl: 'http://localhost:8089' // Exemple d'URL d'API pour le développement
  };