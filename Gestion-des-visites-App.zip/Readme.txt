don't forget to execute

"npm install"

to download all modules for the front-end